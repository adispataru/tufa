#!/bin/bash
echo $(date)": Cloudlightning service started. " >> ./deployment.log