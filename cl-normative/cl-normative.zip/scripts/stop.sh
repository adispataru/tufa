#!/bin/bash
echo $(date)": Cloudlightning service stopped. " >> ./deployment.log