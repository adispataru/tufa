#!/bin/bash
echo $(date)": Cloudlightning service created. Here dependencies may be installed" >> ./deployment.log